-- VolleyCourt Pro — production-oriented Supabase schema
create extension if not exists "pgcrypto";

create type public.app_role as enum ('admin', 'viewer');
create type public.entity_status as enum ('active', 'archived');
create type public.match_status as enum ('scheduled', 'live', 'completed', 'cancelled');
create type public.request_status as enum ('pending', 'approved', 'rejected', 'cancelled');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'User',
  role public.app_role not null default 'viewer',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.competitions (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  status public.entity_status not null default 'active',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.teams (
  id uuid primary key default gen_random_uuid(),
  competition_id uuid references public.competitions(id) on delete set null,
  name text not null,
  short_name text,
  logo_url text,
  color text default '#16d9bd',
  description text,
  captain_name text,
  status public.entity_status not null default 'active',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.team_members (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  player_name text not null,
  jersey_number integer,
  position text,
  status public.entity_status not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  competition_id uuid references public.competitions(id) on delete set null,
  home_team_id uuid not null references public.teams(id),
  away_team_id uuid not null references public.teams(id),
  status public.match_status not null default 'scheduled',
  scheduled_at timestamptz,
  started_at timestamptz,
  completed_at timestamptz,
  best_of integer not null default 3 check (best_of in (1,3,5)),
  points_to_win integer not null default 25 check (points_to_win > 0),
  win_by_two boolean not null default true,
  home_sets integer not null default 0,
  away_sets integer not null default 0,
  created_by uuid references public.profiles(id),
  last_modified_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (home_team_id <> away_team_id)
);

create table if not exists public.sets (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  set_number integer not null,
  home_points integer not null default 0 check (home_points >= 0),
  away_points integer not null default 0 check (away_points >= 0),
  winner_team_id uuid references public.teams(id),
  started_at timestamptz,
  ended_at timestamptz,
  unique(match_id, set_number)
);

create table if not exists public.change_requests (
  id uuid primary key default gen_random_uuid(),
  requested_by uuid not null references public.profiles(id),
  entity_type text not null,
  entity_id uuid not null,
  action text not null,
  payload jsonb not null default '{}'::jsonb,
  reason text,
  status public.request_status not null default 'pending',
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);

create table if not exists public.change_request_approvals (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.change_requests(id) on delete cascade,
  admin_id uuid not null references public.profiles(id) on delete cascade,
  decision text not null check (decision in ('approved','rejected')),
  comment text,
  created_at timestamptz not null default now(),
  unique(request_id, admin_id)
);

create table if not exists public.activity_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.app_settings (
  id integer primary key default 1 check (id = 1),
  scoring jsonb not null default '{"pointsToWin":25,"winByTwo":true,"bestOf":3}'::jsonb,
  require_approval boolean not null default true,
  approval_mode text not null default 'all_other_admins'
    check (approval_mode in ('any_one_other_admin','majority_other_admins','all_other_admins')),
  updated_by uuid references public.profiles(id),
  updated_at timestamptz not null default now()
);

insert into public.app_settings (id)
values (1)
on conflict (id) do nothing;

-- Helper functions
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.active_admin_count()
returns integer
language sql
stable
security definer
set search_path = public
as $$
  select count(*)::integer from public.profiles where role = 'admin';
$$;

-- RLS
alter table public.profiles enable row level security;
alter table public.competitions enable row level security;
alter table public.teams enable row level security;
alter table public.team_members enable row level security;
alter table public.matches enable row level security;
alter table public.sets enable row level security;
alter table public.change_requests enable row level security;
alter table public.change_request_approvals enable row level security;
alter table public.activity_logs enable row level security;
alter table public.app_settings enable row level security;

-- Public viewers can read competition/team/match data.
create policy "public can read competitions"
on public.competitions for select using (true);

create policy "public can read teams"
on public.teams for select using (true);

create policy "public can read team members"
on public.team_members for select using (true);

create policy "public can read matches"
on public.matches for select using (true);

create policy "public can read sets"
on public.sets for select using (true);

-- Authenticated users can read their own profile; admins can read profiles.
create policy "own profile"
on public.profiles for select
using (auth.uid() = id or public.is_admin());

create policy "admins manage profiles"
on public.profiles for update
using (public.is_admin())
with check (public.is_admin());

-- Admin writes. Production approval writes should be routed through RPC/server logic.
create policy "admins manage competitions"
on public.competitions for all
using (public.is_admin())
with check (public.is_admin());

create policy "admins manage teams"
on public.teams for all
using (public.is_admin())
with check (public.is_admin());

create policy "admins manage team members"
on public.team_members for all
using (public.is_admin())
with check (public.is_admin());

create policy "admins manage matches"
on public.matches for all
using (public.is_admin())
with check (public.is_admin());

create policy "admins manage sets"
on public.sets for all
using (public.is_admin())
with check (public.is_admin());

create policy "admins read requests"
on public.change_requests for select
using (public.is_admin());

create policy "admins create requests"
on public.change_requests for insert
with check (public.is_admin() and requested_by = auth.uid());

create policy "admins read approvals"
on public.change_request_approvals for select
using (public.is_admin());

create policy "admins create approvals"
on public.change_request_approvals for insert
with check (public.is_admin() and admin_id = auth.uid());

create policy "admins read logs"
on public.activity_logs for select
using (public.is_admin());

create policy "admins write logs"
on public.activity_logs for insert
with check (public.is_admin() and actor_id = auth.uid());

create policy "public can read settings"
on public.app_settings for select using (true);

create policy "admins manage settings"
on public.app_settings for all
using (public.is_admin())
with check (public.is_admin());

-- Realtime
alter publication supabase_realtime add table public.matches;
alter publication supabase_realtime add table public.sets;
alter publication supabase_realtime add table public.change_requests;
alter publication supabase_realtime add table public.activity_logs;

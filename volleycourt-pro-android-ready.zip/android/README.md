# VolleyCourt Pro Android packaging

This folder is the Android packaging target for the VolleyCourt Pro web app.

Recommended build:
1. Build the web app: `npm install && npm run build`
2. Install Capacitor packages:
   `npm install @capacitor/core @capacitor/cli @capacitor/android`
3. Run:
   `npx cap add android`
   `npx cap sync android`
   `npx cap open android`
4. In Android Studio choose Build > Generate App Bundle / APK.

The final APK can then be uploaded to a public file host or release page and shared.

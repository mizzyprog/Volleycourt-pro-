# VolleyCourt Pro

A premium volleyball match-management dashboard built from scratch from the requested product specification.

## Included in this first working build

- Premium dark navy / jade / marigold visual system
- Custom volleyball app icon
- Responsive dashboard
- Multiple teams
- Team management view
- Match history
- Live scoreboard with +1 / Undo
- Best-of-3 / win-by-2 scoring logic
- Standings and recent-form indicators
- Stats and charts
- Admin approval center UI
- Activity log UI
- Settings for scoring rules
- Public/admin mode switch for the prototype
- Supabase client scaffold
- Production-oriented PostgreSQL schema with RLS and approval workflow
- PWA-ready structure
- Export buttons for CSV / JSON in the UI

## Run locally

1. Install Node.js 20+.
2. In this folder run:

```bash
npm install
npm run dev
```

3. Open the local Vite URL.

## Supabase setup

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the SQL editor.
3. Copy `.env.example` to `.env`.
4. Add your Supabase URL and anon key.
5. Restart the dev server.

The UI currently has safe demo data so it can be explored before Supabase is connected. The next integration step is to replace demo repositories with live Supabase queries and Realtime subscriptions.

## Important security note

Never put the Supabase service-role key in this frontend. Admin permissions must be enforced with Supabase Auth + RLS / server-side functions. The included schema is designed around that model.

## Android APK

The project includes `capacitor.config.json` and an Android packaging guide. A signed APK
must be built with the Android SDK/Gradle toolchain, then uploaded to a public host to create
a shareable download link. For Google Play distribution, generate an Android App Bundle (AAB)
instead of a direct APK.

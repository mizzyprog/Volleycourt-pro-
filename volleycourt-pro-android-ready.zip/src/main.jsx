import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, BarChart3, Bell, Check, ChevronRight, CircleHelp, Clock3,
  Download, FileJson, FileText, Home, LayoutDashboard, LockKeyhole,
  Menu, MoreHorizontal, Play, Plus, RefreshCw, Search, Settings,
  ShieldCheck, Sparkles, Trophy, Undo2, Users, X, Zap
} from "lucide-react";
import {
  BarChart, Bar, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip,
  PieChart, Pie, Legend
} from "recharts";
import { createClient } from "@supabase/supabase-js";
import "./styles.css";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseAnonKey
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

const demoTeams = [
  { id:"t1", name:"Nakkah", short:"NAK", color:"#16d9bd", captain:"Hassan", players:8, status:"Active", wins:8, losses:2, setsW:17, setsL:7 },
  { id:"t2", name:"Nallah", short:"NAL", color:"#f5b82e", captain:"Bilal", players:9, status:"Active", wins:7, losses:3, setsW:16, setsL:9 },
  { id:"t3", name:"Falcons", short:"FAL", color:"#8b7cff", captain:"Usman", players:8, status:"Active", wins:6, losses:4, setsW:14, setsL:10 },
  { id:"t4", name:"Spikers", short:"SPI", color:"#ff6b8a", captain:"Hamza", players:10, status:"Active", wins:4, losses:6, setsW:10, setsL:13 },
  { id:"t5", name:"Titans", short:"TIT", color:"#54a8ff", captain:"Adeel", players:7, status:"Active", wins:3, losses:7, setsW:8, setsL:16 },
];

const initialMatches = [
  { id:"m1", home:"Nakkah", away:"Nallah", homeId:"t1", awayId:"t2", score:"2–1", status:"Live", time:"Today · 8:30 PM", sets:[["25","23"],["21","25"],["15","12"]] },
  { id:"m2", home:"Falcons", away:"Spikers", homeId:"t3", awayId:"t4", score:"2–0", status:"Completed", time:"Today · 6:00 PM", sets:[["25","19"],["25","21"]] },
  { id:"m3", home:"Nallah", away:"Titans", homeId:"t2", awayId:"t5", score:"2–0", status:"Completed", time:"Yesterday · 8:00 PM", sets:[["25","17"],["25","20"]] },
  { id:"m4", home:"Nakkah", away:"Falcons", homeId:"t1", awayId:"t3", score:"2–0", status:"Completed", time:"Sep 18 · 8:30 PM", sets:[["25","20"],["25","22"]] },
];

const setData = [
  {name:"S1", Nakkah:25, Nallah:23},
  {name:"S2", Nakkah:21, Nallah:25},
  {name:"S3", Nakkah:15, Nallah:12},
  {name:"S4", Nakkah:25, Nallah:21},
  {name:"S5", Nakkah:15, Nallah:13},
];

const formData = [
  {name:"Nakkah", value:80},
  {name:"Nallah", value:70},
  {name:"Falcons", value:60},
  {name:"Spikers", value:40},
  {name:"Titans", value:30},
];

const activity = [
  ["Today · 8:44 PM","Bilal Ahmed","Updated Set 3 score","Nakkah vs Nallah"],
  ["Today · 8:39 PM","Muhammad Shujah","Approved match edit","Nakkah vs Nallah"],
  ["Today · 7:55 PM","Hassan Khan","Started live match","Nakkah vs Nallah"],
  ["Today · 6:18 PM","Muhammad Shujah","Created match","Falcons vs Spikers"],
];

function downloadFile(name, content, type) {
  const blob = new Blob([content], {type});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

function App() {
  const [active, setActive] = useState("Dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mode, setMode] = useState("Admin");
  const [matches, setMatches] = useState(initialMatches);
  const [liveHome, setLiveHome] = useState(25);
  const [liveAway, setLiveAway] = useState(23);
  const [setNo, setSetNo] = useState(3);
  const [toast, setToast] = useState("");
  const [search, setSearch] = useState("");
  const [scoring, setScoring] = useState({points:25, winByTwo:true, bestOf:3});

  const notify = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2200);
  };

  const exportJSON = () => {
    downloadFile("volleycourt-backup.json", JSON.stringify({teams:demoTeams,matches,scoring,exportedAt:new Date().toISOString()}, null, 2), "application/json");
    notify("JSON backup exported");
  };

  const exportCSV = () => {
    const rows = [["Match","Home","Away","Score","Status","Time"], ...matches.map(m=>[m.id,m.home,m.away,m.score,m.status,m.time])];
    downloadFile("volleycourt-matches.csv", rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(",")).join("\n"), "text/csv");
    notify("CSV exported");
  };

  const addPoint = (side) => {
    if (mode === "Viewer") return notify("Viewer mode is read-only");
    side === "home" ? setLiveHome(v=>v+1) : setLiveAway(v=>v+1);
    notify("Score updated — pending official save");
  };

  const undo = (side) => {
    if (mode === "Viewer") return;
    side === "home" ? setLiveHome(v=>Math.max(0,v-1)) : setLiveAway(v=>Math.max(0,v-1));
    notify("Last point undone");
  };

  const standings = [...demoTeams].sort((a,b)=> (b.wins-a.wins) || ((b.setsW-b.setsL)-(a.setsW-a.setsL)));

  return (
    <div className="app">
      <aside className={`sidebar ${mobileOpen ? "open":""}`}>
        <div className="brand">
          <img src="/app-icon.png" alt="VolleyCourt Pro" />
          <div><strong>VolleyCourt</strong><span>PRO</span></div>
        </div>
        <div className="competition-chip"><Trophy size={15}/> City Volleyball League <ChevronRight size={14}/></div>
        <nav>
          <NavItem icon={<LayoutDashboard/>} label="Dashboard" active={active==="Dashboard"} onClick={()=>{setActive("Dashboard");setMobileOpen(false)}}/>
          <NavItem icon={<Play/>} label="Live Match" active={active==="Live Match"} onClick={()=>{setActive("Live Match");setMobileOpen(false)}} badge="LIVE"/>
          <NavItem icon={<Users/>} label="Teams" active={active==="Teams"} onClick={()=>{setActive("Teams");setMobileOpen(false)}}/>
          <NavItem icon={<Clock3/>} label="Match History" active={active==="Match History"} onClick={()=>{setActive("Match History");setMobileOpen(false)}}/>
          {mode==="Admin" && <NavItem icon={<ShieldCheck/>} label="Approvals" active={active==="Approvals"} onClick={()=>{setActive("Approvals");setMobileOpen(false)}} badge="3"/>}
          {mode==="Admin" && <NavItem icon={<Activity/>} label="Activity Log" active={active==="Activity Log"} onClick={()=>{setActive("Activity Log");setMobileOpen(false)}}/>}
          {mode==="Admin" && <NavItem icon={<Settings/>} label="Settings" active={active==="Settings"} onClick={()=>{setActive("Settings");setMobileOpen(false)}}/>}
        </nav>
        <div className="sidebar-bottom">
          <div className="admin-card">
            <div className="avatar">MS</div>
            <div><b>Muhammad Shujah</b><small>{mode === "Admin" ? "Administrator" : "Public Viewer"}</small></div>
            <MoreHorizontal size={18}/>
          </div>
          <button className="mode-btn" onClick={()=>setMode(mode==="Admin"?"Viewer":"Admin")}>
            <LockKeyhole size={16}/>{mode==="Admin" ? "Switch to Viewer" : "Switch to Admin"}
          </button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <button className="mobile-menu" onClick={()=>setMobileOpen(!mobileOpen)}><Menu/></button>
          <div className="crumb"><span>City Volleyball League</span><ChevronRight size={14}/><b>{active}</b></div>
          <div className="top-actions">
            <div className="search"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search teams, matches..."/></div>
            <button className="icon-btn"><Bell size={19}/><i/></button>
            <div className="status"><span/> Realtime connected</div>
          </div>
        </header>

        {active==="Dashboard" && <Dashboard standings={standings} setData={setData} formData={formData} matches={matches} onLive={()=>setActive("Live Match")} exportCSV={exportCSV} exportJSON={exportJSON} />}
        {active==="Live Match" && <LiveMatch home={liveHome} away={liveAway} setNo={setNo} addPoint={addPoint} undo={undo} mode={mode} notify={notify} />}
        {active==="Teams" && <Teams teams={demoTeams} mode={mode} notify={notify}/>}
        {active==="Match History" && <History matches={matches} search={search} exportCSV={exportCSV} />}
        {active==="Approvals" && mode==="Admin" && <Approvals notify={notify}/>}
        {active==="Activity Log" && mode==="Admin" && <ActivityLog/>}
        {active==="Settings" && mode==="Admin" && <SettingsView scoring={scoring} setScoring={setScoring} notify={notify}/>}
      </main>
      {toast && <div className="toast"><Check size={17}/>{toast}</div>}
    </div>
  );
}

function NavItem({icon,label,active,onClick,badge}) {
  return <button className={`nav-item ${active?"active":""}`} onClick={onClick}>{icon}<span>{label}</span>{badge&&<em>{badge}</em>}</button>
}

function SectionTitle({eyebrow,title,action}) {
  return <div className="section-title"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2></div>{action}</div>
}

function Dashboard({standings,setData,formData,matches,onLive,exportCSV,exportJSON}) {
  return <div className="content">
    <section className="hero">
      <div>
        <div className="live-pill"><span/> LIVE MATCH</div>
        <p className="hero-kicker">COURT 01 · CITY VOLLEYBALL LEAGUE</p>
        <h1>Nakkah <span>vs</span> Nallah</h1>
        <p className="hero-sub">Set 3 · 12:48 elapsed · First to 25, win by 2</p>
        <div className="hero-score"><b>25</b><small>–</small><b>23</b></div>
        <div className="hero-meta"><span><Clock3 size={15}/> Set 3 of 3</span><span><Zap size={15}/> Real-time scoring</span></div>
      </div>
      <div className="hero-right">
        <div className="team-mark teal">NAK</div><div className="vs">VS</div><div className="team-mark gold">NAL</div>
        <button className="primary" onClick={onLive}><Play size={17}/> Open live scoreboard</button>
      </div>
    </section>

    <div className="stat-grid">
      <Stat icon={<Trophy/>} label="Matches Played" value="24" trend="+3 this week"/>
      <Stat icon={<Zap/>} label="Total Sets" value="51" trend="+7 this week"/>
      <Stat icon={<Users/>} label="Active Teams" value="5" trend="2 matches today"/>
      <Stat icon={<ShieldCheck/>} label="Approved Changes" value="38" trend="100% audited"/>
    </div>

    <div className="grid-2">
      <section className="panel chart-panel">
        <SectionTitle eyebrow="RECENT SETS" title="Point-by-point snapshot" action={<button className="ghost">View stats <ChevronRight size={15}/></button>}/>
        <div className="chart"><ResponsiveContainer width="100%" height="230"><BarChart data={setData} barGap={8}><XAxis dataKey="name" axisLine={false} tickLine={false}/><YAxis axisLine={false} tickLine={false}/><Tooltip contentStyle={{background:"#101a24",border:"1px solid #263747",borderRadius:12}}/><Bar dataKey="Nakkah" fill="#16d9bd" radius={[6,6,0,0]}/><Bar dataKey="Nallah" fill="#f5b82e" radius={[6,6,0,0]}/></BarChart></ResponsiveContainer></div>
      </section>

      <section className="panel chart-panel">
        <SectionTitle eyebrow="FORM" title="Team win rate" action={<span className="muted">Season</span>}/>
        <div className="donut-wrap">
          <ResponsiveContainer width="52%" height="210"><PieChart><Pie data={formData} dataKey="value" nameKey="name" innerRadius={57} outerRadius={80} paddingAngle={4}><Cell fill="#16d9bd"/><Cell fill="#f5b82e"/><Cell fill="#8b7cff"/><Cell fill="#ff6b8a"/><Cell fill="#54a8ff"/></Pie><Legend verticalAlign="bottom" height={30}/></PieChart></ResponsiveContainer>
          <div className="donut-center"><b>60%</b><span>League avg</span></div>
        </div>
      </section>
    </div>

    <section className="panel">
      <SectionTitle eyebrow="LEAGUE TABLE" title="Standings" action={<button className="ghost">Full table <ChevronRight size={15}/></button>}/>
      <div className="table-wrap"><table><thead><tr><th>#</th><th>Team</th><th>MP</th><th>W</th><th>L</th><th>Sets</th><th>Win %</th><th>Form</th></tr></thead><tbody>{standings.map((t,i)=><tr key={t.id}><td><b>{String(i+1).padStart(2,"0")}</b></td><td><div className="team-cell"><span className="team-dot" style={{background:t.color}}/>{t.name}</div></td><td>{t.wins+t.losses}</td><td className="positive">{t.wins}</td><td>{t.losses}</td><td>{t.setsW}:{t.setsL}</td><td><b>{Math.round(t.wins/(t.wins+t.losses)*100)}%</b></td><td><span className="form-dots"><i/><i/><i className="loss"/><i/><i/></span></td></tr>)}</tbody></table></div>
    </section>

    <div className="grid-2">
      <section className="panel">
        <SectionTitle eyebrow="RECENT" title="Matches" action={<button className="ghost">All matches <ChevronRight size={15}/></button>}/>
        <div className="match-list">{matches.slice(0,4).map(m=><MatchRow key={m.id} m={m}/>)}</div>
      </section>
      <section className="panel quick-panel">
        <SectionTitle eyebrow="ADMIN TOOLS" title="Quick actions"/>
        <div className="quick-grid">
          <button><Plus/><span>New match</span><small>Create and schedule</small></button>
          <button><Users/><span>Manage teams</span><small>Players & captains</small></button>
          <button><FileText/><span>Export CSV</span><small>Match records</small></button>
          <button><FileJson/><span>Backup JSON</span><small>Full data snapshot</small></button>
        </div>
        <div className="export-row"><button className="ghost" onClick={exportCSV}><Download size={15}/> Export CSV</button><button className="ghost" onClick={exportJSON}><Download size={15}/> Backup JSON</button></div>
      </section>
    </div>
  </div>
}

function Stat({icon,label,value,trend}) {
  return <div className="stat"><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{trend}</small></div></div>
}

function MatchRow({m}) {
  return <div className="match-row"><div className={`match-status ${m.status.toLowerCase()}`}><span/>{m.status}</div><div className="match-teams"><b>{m.home}</b><small>vs</small><b>{m.away}</b></div><div className="match-score">{m.score}</div><div className="match-time">{m.time}</div><ChevronRight size={17}/></div>
}

function LiveMatch({home,away,setNo,addPoint,undo,mode,notify}) {
  const homeWon = home > away;
  return <div className="content">
    <SectionTitle eyebrow="LIVE COURT 01" title="Official Scoreboard" action={<div className="live-pill"><span/> LIVE</div>}/>
    <section className="scoreboard panel">
      <div className="score-top"><span>Nakkah</span><div className="set-badges"><i className="won">1</i><i className="won">1</i><i className="current">{setNo}</i></div><span>Nallah</span></div>
      <div className="score-main"><div className="score-team"><small>HOME</small><h3>NAK</h3><strong>{home}</strong><button className="score-btn teal-btn" onClick={()=>addPoint("home")} disabled={mode==="Viewer"}>+1</button><button className="undo" onClick={()=>undo("home")}><Undo2 size={15}/> Undo</button></div><div className="score-vs">:</div><div className="score-team"><small>AWAY</small><h3>NAL</h3><strong>{away}</strong><button className="score-btn gold-btn" onClick={()=>addPoint("away")} disabled={mode==="Viewer"}>+1</button><button className="undo" onClick={()=>undo("away")}><Undo2 size={15}/> Undo</button></div></div>
      <div className="score-rules"><span><ShieldCheck size={15}/> First to 25</span><span><Zap size={15}/> Win by 2: ON</span><span><Trophy size={15}/> Best of 3</span></div>
      {mode==="Viewer" && <div className="readonly-banner"><LockKeyhole size={16}/> Viewer mode — scoreboard is read-only.</div>}
      <div className="set-history"><b>Set history</b><div className="set-line"><span>Set 1</span><strong>25 – 23</strong><span className="set-win">Nakkah</span></div><div className="set-line"><span>Set 2</span><strong>21 – 25</strong><span className="set-win away">Nallah</span></div><div className="set-line current-line"><span>Set 3</span><strong>{home} – {away}</strong><span className="live-dot">Live</span></div></div>
    </section>
    <div className="grid-2"><section className="panel"><SectionTitle eyebrow="MATCH CONTROL" title="Official actions"/><div className="action-stack"><button className="primary" onClick={()=>notify("Match saved as official data")}><Check/> Save official score</button><button className="ghost big" onClick={()=>notify("Edit request sent for admin approval")}><ShieldCheck/> Request correction / edit</button><button className="danger" onClick={()=>notify("Delete request sent for approval")}><X/> Request match deletion</button></div></section><section className="panel"><SectionTitle eyebrow="LIVE STATUS" title="Realtime activity"/><div className="mini-feed"><p><span className="pulse"/> Score update synchronized</p><p><Clock3/> Last update 8:44:12 PM</p><p><Users/> 3 admins online</p><p><ShieldCheck/> Official changes require approval</p></div></section></div>
  </div>
}

function Teams({teams,mode,notify}) {
  return <div className="content"><SectionTitle eyebrow="ROSTER MANAGEMENT" title="Teams" action={mode==="Admin"&&<button className="primary" onClick={()=>notify("New team form opened")}><Plus/> Add team</button>}/><div className="team-grid">{teams.map(t=><div className="team-card panel" key={t.id}><div className="team-card-head"><div className="big-team-logo" style={{background:`linear-gradient(135deg,${t.color}33,transparent)`,borderColor:t.color}}>{t.short}</div><div><h3>{t.name}</h3><span className="active-label"><i/> {t.status}</span></div><button className="icon-btn"><MoreHorizontal/></button></div><p>Captain: <b>{t.captain}</b></p><div className="team-stats"><span><b>{t.players}</b> Players</span><span><b>{t.wins}</b> Wins</span><span><b>{t.losses}</b> Losses</span></div><div className="team-card-foot"><span>Win rate <b>{Math.round(t.wins/(t.wins+t.losses)*100)}%</b></span><button className="ghost" onClick={()=>notify(`${t.name} details opened`)}>View team <ChevronRight size={14}/></button></div></div>)}</div></div>
}

function History({matches,search,exportCSV}) {
  const filtered=matches.filter(m=>`${m.home} ${m.away} ${m.status}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="content"><SectionTitle eyebrow="OFFICIAL RECORDS" title="Match History" action={<button className="ghost" onClick={exportCSV}><Download size={16}/> Export CSV</button>}/><section className="panel"><div className="history-filter"><div className="filter-chip active">All matches</div><div className="filter-chip">Completed</div><div className="filter-chip">Live</div><div className="filter-chip">Scheduled</div></div>{filtered.map(m=><div className="history-row" key={m.id}><div className={`match-status ${m.status.toLowerCase()}`}><span/>{m.status}</div><div className="history-teams"><b>{m.home}</b><small>vs</small><b>{m.away}</b></div><div className="history-score">{m.score}</div><div className="history-sets">{m.sets.map((s,i)=><span key={i}>{s[0]}–{s[1]}</span>)}</div><div className="history-time">{m.time}</div><ChevronRight size={17}/></div>)}</section></div>
}

function Approvals({notify}) {
  const requests=[["CR-1042","Edit Set 3 score","Nakkah vs Nallah","Bilal Ahmed","2 of 3 approvals"],["CR-1041","Update team captain","Falcons","Hassan Khan","1 of 2 approvals"],["CR-1040","Delete duplicate match","Spikers vs Titans","Muhammad Shujah","0 of 2 approvals"]];
  return <div className="content"><SectionTitle eyebrow="GOVERNANCE" title="Approval Center" action={<span className="approval-note"><ShieldCheck/> Changes are audited</span>}/><div className="approval-banner"><ShieldCheck/><div><b>Multi-admin approval is enabled</b><span>An admin cannot approve their own request. Official changes require the configured number of independent approvals.</span></div></div><div className="approval-list">{requests.map(r=><div className="approval-card panel" key={r[0]}><div className="approval-id">{r[0]}</div><div className="approval-main"><h3>{r[1]}</h3><p>{r[2]} · Requested by <b>{r[3]}</b></p><small>{r[4]}</small></div><button className="approve" onClick={()=>notify(`Approval recorded for ${r[0]}`)}><Check/> Approve</button><button className="reject" onClick={()=>notify(`Rejection recorded for ${r[0]}`)}><X/> Reject</button></div>)}</div></div>
}

function ActivityLog() {
  return <div className="content"><SectionTitle eyebrow="AUDIT TRAIL" title="Activity Log" action={<button className="ghost"><RefreshCw size={15}/> Refresh</button>}/><section className="panel"><div className="activity-table">{activity.map((a,i)=><div className="activity-row" key={i}><span>{a[0]}</span><b>{a[1]}</b><strong>{a[2]}</strong><em>{a[3]}</em></div>)}</div></section></div>
}

function SettingsView({scoring,setScoring,notify}) {
  return <div className="content"><SectionTitle eyebrow="SYSTEM CONFIGURATION" title="Settings"/><div className="settings-grid"><section className="panel settings-card"><div className="settings-head"><div className="setting-icon"><Zap/></div><div><h3>Scoring rules</h3><p>Configure defaults used when new matches are created.</p></div></div><label>Points to win<input type="number" value={scoring.points} onChange={e=>setScoring({...scoring,points:+e.target.value})}/></label><label>Best of<select value={scoring.bestOf} onChange={e=>setScoring({...scoring,bestOf:+e.target.value})}><option value="1">1</option><option value="3">3</option><option value="5">5</option></select></label><label className="toggle-row">Win by 2 <input type="checkbox" checked={scoring.winByTwo} onChange={e=>setScoring({...scoring,winByTwo:e.target.checked})}/></label><button className="primary" onClick={()=>notify("Scoring settings saved")}>Save settings</button></section><section className="panel settings-card"><div className="settings-head"><div className="setting-icon"><ShieldCheck/></div><div><h3>Approval policy</h3><p>Protect official records from unilateral edits.</p></div></div><label>Approval mode<select defaultValue="all_other_admins"><option value="all_other_admins">All other active admins</option><option value="majority_other_admins">Majority of other admins</option><option value="any_one_other_admin">Any one other admin</option></select></label><div className="security-list"><p><Check/> Admin cannot approve own request</p><p><Check/> Every decision is timestamped</p><p><Check/> Full activity history is retained</p><p><Check/> Public viewers have no write access</p></div></section></div></div>
}

const root = createRoot(document.getElementById("root"));
root.render(<App />);
